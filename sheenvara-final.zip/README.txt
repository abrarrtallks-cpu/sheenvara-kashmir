Sheenvara Kashmir - final site (18 pages, SEO optimized)
Deploy: Netlify > Add new site > Deploy manually > drag this whole folder.
Domain: https://sheenvarakashmir.com
SEO files: sitemap.xml, robots.txt, llms.txt, favicon/icons, site.webmanifest, 404.html, _headers, _redirects
After the domain is connected:
 1. Google Search Console: add the site and submit /sitemap.xml
 2. Bing Webmaster Tools: import from Search Console
 3. Google Business Profile: use the same name, address and phone as the site
 4. Test pages in Google Rich Results Test
Forms: "enquiry" and "newsletter" show in Netlify > Forms.
